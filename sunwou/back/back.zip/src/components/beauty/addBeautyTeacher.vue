<template>
  <div>beauty teacher</div>
</template>
