<template>
  <div>店铺装修--开发中...<br>给我们程序员一个机会</div>
</template>
